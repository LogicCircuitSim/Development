package engine.events;

public record MouseMoveEvent(float x, float y) { }
