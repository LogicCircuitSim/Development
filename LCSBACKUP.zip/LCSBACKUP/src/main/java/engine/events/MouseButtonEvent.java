package engine.events;

public record MouseButtonEvent(int button, int buttonState) { }