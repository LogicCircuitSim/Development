package engine.events;

public record MouseWheelEvent(int x, int y) { }
