package engine.components;

public class Switch extends Input {
}
