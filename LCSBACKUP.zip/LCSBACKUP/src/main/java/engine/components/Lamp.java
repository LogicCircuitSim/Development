package engine.components;

public class Lamp extends Output {
}
