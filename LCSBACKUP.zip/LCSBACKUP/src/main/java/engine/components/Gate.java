package engine.components;

import imgui.ImVec2;

public class Gate extends Component {
	public void show() { }
	
}
