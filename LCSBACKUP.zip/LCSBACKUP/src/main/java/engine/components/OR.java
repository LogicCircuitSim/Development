package engine.components;

public class OR extends Gate {
}
