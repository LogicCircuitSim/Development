package engine.components;

public class Output extends Peripheral {
}
