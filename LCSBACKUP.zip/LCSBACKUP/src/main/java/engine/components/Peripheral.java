package engine.components;

public class Peripheral extends Component {
}
