package engine.components;

public class Pin extends BoardObject {
}
