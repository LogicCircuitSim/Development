package engine.components;

public class Cable extends ConnectionObject {
}
