package engine.components;

public class Component extends BoardObject {
}
