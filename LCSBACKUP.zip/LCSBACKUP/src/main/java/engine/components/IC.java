package engine.components;

public class IC extends Component {
}
