package engine.components;

public class ConnectionObject extends BoardObject {
}
