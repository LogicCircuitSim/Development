package engine.components;

public class Connection {
}
