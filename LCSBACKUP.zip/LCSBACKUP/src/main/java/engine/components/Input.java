package engine.components;

public class Input extends Peripheral {
}
